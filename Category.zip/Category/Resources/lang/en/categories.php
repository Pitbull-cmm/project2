<?php
return [
    'categories' => 'Categories',
    'general' => 'General',
    'save'=>'Save',
    'form'=>[
        'name' => 'Name',
        'searchable' => 'Searchable',
        'show_in_search'=>'Show this categoru in search box category list',
        'status'=>'Status',
        'enable'=>'Enable the category',
    ],
];
