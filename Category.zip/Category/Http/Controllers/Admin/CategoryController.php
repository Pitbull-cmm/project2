<?php

namespace Modules\Category\Http\Controllers\Admin;

use App\Models\Category;
use Illuminate\Contracts\View\Factory;
use Illuminate\Contracts\View\View;
use Illuminate\Foundation\Application;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Modules\Admin\Traits\HasCrudActions;
use Modules\Category\Entities\Category as EntitiesCategory;
use Carbon\Carbon;
class CategoryController
{
    /**
     * Model for the resource.
     *
     * @var string
     */
//    protected string $model = Category::class;

    /**
     * Label of the resource.
     *
     * @var string
     */
    protected string $label = 'category::categories.category';

    /**
     * View path of the resource.
     *
     * @var string
     */
    protected string $viewPath = 'category::admin.categories';

    /**
     * Store a newly created resource in storage.
     *
     * @return Response
     */
    // public function index(Request $request)
    // {
    //     $categories = Category::all();
    //     return view("{$this->viewPath}.index",compact('categories'));
    // }
    public function index(Request $request)
    {

        // Trả dữ liệu về view
        return view("{$this->viewPath}.index");
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create()
    {
        return view("{$this->viewPath}.create");
    }

    /**
     * Store a newly created resource in storage.
     *
     * @return Response|JsonResponse
     */
    public function store(Request $request)
    {


    }


    /**
     * Show the form for editing the specified resource.
     *
     * @param int $id
     *
     * @return Factory|View|Application
     */
    public function edit($id)
    {

    }


    /**
     * Update the specified resource in storage.
     *
     * @param int $id
     */
    public function update(Request $request, $id)
    {

    }

    /**
     * Get request object
     *
     * @param string $action
     *
     * @return Request
     */
    protected function getRequest(string $action): Request
    {
        return match (true) {
            !isset($this->validation) => request(),
            isset($this->validation[$action]) => resolve($this->validation[$action]),
            default => resolve($this->validation),
        };
    }

    public function bulkDelete(Request $request)
    {

    }


}
